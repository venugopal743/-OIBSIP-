import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.*;

/**
 * Console-based Online Examination System
 * Single-file example: OnlineExamApp.java
 *
 * Features:
 * - User login (SHA-256 hashed password)
 * - Update profile & password
 * - MCQ selection
 * - Timer + auto-submit
 * - Session logout
 *
 * Persistence: serialized objects stored in files
 */

public class OnlineExamApp {
    // Paths for storage
    private static final Path USERS_FILE = Paths.get("users.dat");
    private static final Path QUESTIONS_FILE = Paths.get("questions.dat");

    // In-memory maps loaded from disk
    private static Map<String, User> users = new HashMap<>();
    private static List<Question> questions = new ArrayList<>();

    // Scanner for console input
    private static final Scanner scanner = new Scanner(System.in);

    // Currently logged in user
    private static User currentUser;

    // Main entry
    public static void main(String[] args) {
        loadData();
        ensureSampleData();

        while (true) {
            if (currentUser == null) {
                showAuthMenu();
            } else {
                showUserMenu();
            }
        }
    }

    // ---------- Menus ----------

    private static void showAuthMenu() {
        System.out.println("\n=== ONLINE EXAM - AUTH ===");
        System.out.println("1. Login");
        System.out.println("2. Register");
        System.out.println("3. Exit");
        System.out.print("Choose: ");
        String c = scanner.nextLine().trim();
        switch (c) {
            case "1": login(); break;
            case "2": register(); break;
            case "3": {
                saveData();
                System.out.println("Bye!");
                System.exit(0);
            }
            default: System.out.println("Invalid choice.");
        }
    }

    private static void showUserMenu() {
        System.out.println("\n=== ONLINE EXAM - USER: " + currentUser.getUsername() + " ===");
        System.out.println("1. Update Profile");
        System.out.println("2. Change Password");
        System.out.println("3. Start Exam");
        System.out.println("4. Logout");
        System.out.print("Choose: ");
        String c = scanner.nextLine().trim();
        switch (c) {
            case "1": updateProfile(); break;
            case "2": changePassword(); break;
            case "3": startExam(); break;
            case "4": logout(); break;
            default: System.out.println("Invalid choice.");
        }
    }

    // ---------- Auth ----------

    private static void login() {
        System.out.print("Username: ");
        String uname = scanner.nextLine().trim();
        System.out.print("Password: ");
        String pwd = readHiddenLine();

        User u = users.get(uname);
        if (u == null) {
            System.out.println("User not found.");
            return;
        }
        if (u.verifyPassword(pwd)) {
            currentUser = u;
            System.out.println("Login successful. Welcome, " + u.getFullName() + "!");
        } else {
            System.out.println("Invalid credentials.");
        }
    }

    private static void register() {
        System.out.print("Choose username: ");
        String uname = scanner.nextLine().trim();
        if (users.containsKey(uname)) {
            System.out.println("Username taken.");
            return;
        }
        System.out.print("Full name: ");
        String full = scanner.nextLine().trim();
        System.out.print("Password: ");
        String pwd = readHiddenLine();

        User u = new User(uname, full);
        u.setPasswordPlain(pwd);
        users.put(uname, u);
        saveData();
        System.out.println("Registration successful. You may login now.");
    }

    // ---------- Profile & Password ----------

    private static void updateProfile() {
        System.out.println("Current full name: " + currentUser.getFullName());
        System.out.print("Enter new full name (or blank to keep): ");
        String full = scanner.nextLine().trim();
        if (!full.isEmpty()) {
            currentUser.setFullName(full);
            saveData();
            System.out.println("Profile updated.");
        } else {
            System.out.println("No changes made.");
        }
    }

    private static void changePassword() {
        System.out.print("Enter current password: ");
        String oldPwd = readHiddenLine();
        if (!currentUser.verifyPassword(oldPwd)) {
            System.out.println("Incorrect current password.");
            return;
        }
        System.out.print("Enter new password: ");
        String newPwd = readHiddenLine();
        currentUser.setPasswordPlain(newPwd);
        saveData();
        System.out.println("Password changed successfully.");
    }

    // ---------- Exam ----------

    private static void startExam() {
        System.out.println("\n--- Exam Starting ---");
        System.out.println("You will have 2 minutes (120 seconds) for the exam in this demo.");
        System.out.print("Press Enter to begin...");
        scanner.nextLine();

        // Create session
        ExamSession session = new ExamSession(currentUser, questions);

        // Run exam with timer using ScheduledExecutorService
        ScheduledExecutorService scheduler = Executors.newSingleThreadScheduledExecutor();
        // Schedule auto-submit in sessionDuration seconds
        long sessionDuration = 120L; // seconds (demo). You can change or make configurable.
        final ScheduledFuture<?> autoSubmitHandle = scheduler.schedule(() -> {
            System.out.println("\n\n*** Time is up! Auto-submitting the exam... ***");
            session.autoSubmit();
        }, sessionDuration, TimeUnit.SECONDS);

        // Start interactive exam loop (allows early submit)
        session.runInteractive(scanner);

        // If user submitted early, cancel the scheduled auto-submit
        if (!autoSubmitHandle.isDone()) {
            autoSubmitHandle.cancel(true);
        }
        scheduler.shutdownNow();

        // After session ends, record results to user object (simple)
        currentUser.addLastScore(session.getScore());
        saveData();

        System.out.println("Exam finished. Score: " + session.getScore() + " / " + questions.size());
    }

    // ---------- Logout ----------

    private static void logout() {
        System.out.println("Logging out " + currentUser.getUsername());
        currentUser = null;
    }

    // ---------- Persistence ----------

    private static void loadData() {
        // Load users
        if (Files.exists(USERS_FILE)) {
            try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(USERS_FILE))) {
                Object obj = in.readObject();
                if (obj instanceof Map) {
                    //noinspection unchecked
                    users = (Map<String, User>) obj;
                }
            } catch (Exception e) {
                System.err.println("Failed to load users.dat: " + e.getMessage());
            }
        }
        // Load questions
        if (Files.exists(QUESTIONS_FILE)) {
            try (ObjectInputStream in = new ObjectInputStream(Files.newInputStream(QUESTIONS_FILE))) {
                Object obj = in.readObject();
                if (obj instanceof List) {
                    //noinspection unchecked
                    questions = (List<Question>) obj;
                }
            } catch (Exception e) {
                System.err.println("Failed to load questions.dat: " + e.getMessage());
            }
        }
    }

    private static void saveData() {
        // Save users
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(USERS_FILE))) {
            out.writeObject(users);
        } catch (Exception e) {
            System.err.println("Failed to save users.dat: " + e.getMessage());
        }
        // Save questions
        try (ObjectOutputStream out = new ObjectOutputStream(Files.newOutputStream(QUESTIONS_FILE))) {
            out.writeObject(questions);
        } catch (Exception e) {
            System.err.println("Failed to save questions.dat: " + e.getMessage());
        }
    }

    // ---------- Utilities ----------

    private static void ensureSampleData() {
        // Add a sample admin user and questions if no data exists
        if (users.isEmpty()) {
            User admin = new User("student1", "Alice Example");
            admin.setPasswordPlain("password"); // demo password
            users.put(admin.getUsername(), admin);
            saveData();
            System.out.println("Created sample user: student1 / password");
        }
        if (questions.isEmpty()) {
            questions.add(new Question("What is the capital of France?",
                    Arrays.asList("Berlin", "Paris", "Rome", "Madrid"), 1));
            questions.add(new Question("2 + 2 = ?",
                    Arrays.asList("3", "4", "22", "5"), 1));
            questions.add(new Question("Which language runs on the JVM?",
                    Arrays.asList("Python", "C++", "Java", "Go"), 2));
            saveData();
            System.out.println("Created sample questions (3).");
        }
    }

    // Read password-like input (no real hiding in console here; fallback)
    private static String readHiddenLine() {
        // Try to use java.io.Console if available (hides input)
        Console console = System.console();
        if (console != null) {
            char[] chars = console.readPassword();
            return new String(chars);
        } else {
            // fallback (visible)
            return scanner.nextLine();
        }
    }
}

/* ------------------------- Supporting classes ------------------------- */

class User implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String username;
    private String fullName;
    private String passwordHashHex; // SHA-256 hex string
    private final List<Integer> lastScores = new ArrayList<>(); // store past scores

    public User(String username, String fullName) {
        this.username = username;
        this.fullName = fullName;
    }

    // Set password from plain text (hashes it)
    public void setPasswordPlain(String pwd) {
        this.passwordHashHex = Util.sha256Hex(pwd);
    }

    public boolean verifyPassword(String plain) {
        if (passwordHashHex == null) return false;
        return passwordHashHex.equals(Util.sha256Hex(plain));
    }

    public String getUsername() { return username; }
    public String getFullName() { return fullName; }
    public void setFullName(String name) { this.fullName = name; }

    public void addLastScore(int score) {
        lastScores.add(score);
        if (lastScores.size() > 10) lastScores.remove(0);
    }

    public List<Integer> getLastScores() {
        return Collections.unmodifiableList(lastScores);
    }
}

class Question implements Serializable {
    private static final long serialVersionUID = 1L;

    private final String text;
    private final List<String> options;
    private final int correctOptionIndex; // 0-based

    public Question(String text, List<String> options, int correctOptionIndex) {
        if (correctOptionIndex < 0 || correctOptionIndex >= options.size())
            throw new IllegalArgumentException("Invalid correct option index.");
        this.text = text;
        this.options = new ArrayList<>(options);
        this.correctOptionIndex = correctOptionIndex;
    }

    public String getText() { return text; }
    public List<String> getOptions() { return Collections.unmodifiableList(options); }
    public int getCorrectOptionIndex() { return correctOptionIndex; }
}

/**
 * ExamSession: holds a user's attempt. Allows interactive answering.
 */
class ExamSession {
    private final User user;
    private final List<Question> questions;
    private final Map<Integer, Integer> answers = new HashMap<>(); // qIndex -> selectedOptionIndex
    private boolean submitted = false;
    private int score = 0;

    public ExamSession(User user, List<Question> questions) {
        this.user = user;
        // clone question list to freeze for this session
        this.questions = new ArrayList<>(questions);
    }

    // Run interactive exam: user can answer questions, review, and submit early
    public void runInteractive(Scanner scanner) {
        while (!submitted) {
            System.out.println("\nExam Menu:");
            System.out.println("1. Answer questions");
            System.out.println("2. Review selections");
            System.out.println("3. Submit exam now");
            System.out.print("Choose: ");
            String c = scanner.nextLine().trim();
            switch (c) {
                case "1": answerQuestions(scanner); break;
                case "2": reviewSelections(); break;
                case "3": {
                    submit();
                    return;
                }
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private void answerQuestions(Scanner scanner) {
        for (int i = 0; i < questions.size() && !submitted; i++) {
            Question q = questions.get(i);
            System.out.println("\nQ" + (i + 1) + ": " + q.getText());
            List<String> opts = q.getOptions();
            for (int j = 0; j < opts.size(); j++) {
                System.out.println("   " + (j + 1) + ". " + opts.get(j));
            }
            System.out.println("Current selection: " + (answers.containsKey(i) ? (answers.get(i) + 1) : "None"));
            System.out.print("Choose option number (or press Enter to skip, S to stop answering): ");
            String line = scanner.nextLine().trim();
            if (line.equalsIgnoreCase("S")) {
                System.out.println("Stopped answering.");
                return;
            }
            if (line.isEmpty()) continue;
            try {
                int choice = Integer.parseInt(line);
                if (choice < 1 || choice > opts.size()) {
                    System.out.println("Invalid option number.");
                } else {
                    answers.put(i, choice - 1);
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input.");
            }
        }
    }

    private void reviewSelections() {
        System.out.println("\n--- Review ---");
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            System.out.print("Q" + (i + 1) + ": " + (answers.containsKey(i) ? ("Selected: " + (answers.get(i) + 1)) : "Not answered"));
            System.out.println("  - " + q.getText());
        }
    }

    public void submit() {
        if (submitted) return;
        submitted = true;
        computeScore();
        System.out.println("Submitted. Score: " + score + " / " + questions.size());
    }

    // Called by scheduled auto-submit thread
    public void autoSubmit() {
        synchronized (this) {
            if (submitted) return;
            submitted = true;
            computeScore();
            System.out.println("\nAuto-submitted. Score: " + score + " / " + questions.size());
        }
    }

    private void computeScore() {
        int s = 0;
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            Integer sel = answers.get(i);
            if (sel != null && sel == q.getCorrectOptionIndex()) s++;
        }
        this.score = s;
    }

    public int getScore() { return score; }
}

/* ------------------------- Small utilities ------------------------- */

class Util {
    // SHA-256 hex string
    public static String sha256Hex(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] dig = md.digest(input.getBytes(StandardCharsets.UTF_8));
            return bytesToHex(dig);
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException(e);
        }
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) {
            sb.append(String.format("%02x", b & 0xff));
        }
        return sb.toString();
    }
}
