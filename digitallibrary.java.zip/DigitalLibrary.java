import java.util.*;

class Book {
    int id;
    String title;
    String author;
    boolean issued;

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.issued = false;
    }

    @Override
    public String toString() {
        return id + ". " + title + " by " + author + (issued ? " (Issued)" : "");
    }
}

class Member {
    int id;
    String name;

    public Member(int id, String name) {
        this.id = id;
        this.name = name;
    }
}

class Library {
    List<Book> books = new ArrayList<>();
    List<Member> members = new ArrayList<>();

    // Admin operations
    public void addBook(Book book) { books.add(book); }
    public void removeBook(int id) { books.removeIf(b -> b.id == id); }
    public void updateBook(int id, String title, String author) {
        for (Book b : books) {
            if (b.id == id) {
                b.title = title;
                b.author = author;
            }
        }
    }
    public void addMember(Member m) { members.add(m); }

    // User operations
    public void viewBooks() {
        books.forEach(System.out::println);
    }
    public void searchBook(String keyword) {
        books.stream()
            .filter(b -> b.title.toLowerCase().contains(keyword.toLowerCase()))
            .forEach(System.out::println);
    }
    public boolean issueBook(int bookId) {
        for (Book b : books) {
            if (b.id == bookId && !b.issued) {
                b.issued = true;
                return true;
            }
        }
        return false;
    }
    public boolean returnBook(int bookId) {
        for (Book b : books) {
            if (b.id == bookId && b.issued) {
                b.issued = false;
                return true;
            }
        }
        return false;
    }
}

public class DigitalLibrary {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Library library = new Library();

        // Sample data
        library.addBook(new Book(1, "Java Basics", "James Gosling"));
        library.addBook(new Book(2, "Data Structures", "Robert Lafore"));
        library.addMember(new Member(1, "Alice"));
        library.addMember(new Member(2, "Bob"));

        System.out.println("=== DIGITAL LIBRARY ===");
        System.out.print("Login as (admin/user): ");
        String role = sc.nextLine();

        if (role.equalsIgnoreCase("admin")) {
            while (true) {
                System.out.println("\n--- Admin Menu ---");
                System.out.println("1. Add Book");
                System.out.println("2. Remove Book");
                System.out.println("3. Update Book");
                System.out.println("4. View Books");
                System.out.println("5. Add Member");
                System.out.println("6. Exit");
                System.out.print("Choose: ");
                int choice = sc.nextInt(); sc.nextLine();

                switch (choice) {
                    case 1:
                        System.out.print("Enter book id: "); int id = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter title: "); String title = sc.nextLine();
                        System.out.print("Enter author: "); String author = sc.nextLine();
                        library.addBook(new Book(id, title, author));
                        System.out.println("Book added.");
                        break;
                    case 2:
                        System.out.print("Enter book id to remove: "); int rid = sc.nextInt();
                        library.removeBook(rid);
                        System.out.println("Book removed.");
                        break;
                    case 3:
                        System.out.print("Enter book id to update: "); int uid = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter new title: "); String nt = sc.nextLine();
                        System.out.print("Enter new author: "); String na = sc.nextLine();
                        library.updateBook(uid, nt, na);
                        System.out.println("Book updated.");
                        break;
                    case 4:
                        library.viewBooks();
                        break;
                    case 5:
                        System.out.print("Enter member id: "); int mid = sc.nextInt(); sc.nextLine();
                        System.out.print("Enter member name: "); String mname = sc.nextLine();
                        library.addMember(new Member(mid, mname));
                        System.out.println("Member added.");
                        break;
                    case 6:
                        return;
                }
            }
        } else if (role.equalsIgnoreCase("user")) {
            while (true) {
                System.out.println("\n--- User Menu ---");
                System.out.println("1. View Books");
                System.out.println("2. Search Book");
                System.out.println("3. Issue Book");
                System.out.println("4. Return Book");
                System.out.println("5. Exit");
                System.out.print("Choose: ");
                int choice = sc.nextInt(); sc.nextLine();

                switch (choice) {
                    case 1:
                        library.viewBooks();
                        break;
                    case 2:
                        System.out.print("Enter keyword: ");
                        String kw = sc.nextLine();
                        library.searchBook(kw);
                        break;
                    case 3:
                        System.out.print("Enter book id to issue: ");
                        int bid = sc.nextInt();
                        if (library.issueBook(bid))
                            System.out.println("Book issued.");
                        else
                            System.out.println("Book unavailable.");
                        break;
                    case 4:
                        System.out.print("Enter book id to return: ");
                        int rid = sc.nextInt();
                        if (library.returnBook(rid))
                            System.out.println("Book returned.");
                        else
                            System.out.println("Invalid book id or not issued.");
                        break;
                    case 5:
                        return;
                }
            }
        }
    }
}

